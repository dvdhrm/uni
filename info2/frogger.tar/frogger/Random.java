// Random values
public class Random {
    // Return random boolean value
    static boolean rand_bool()
    {
        return (Math.random() + 0.5) >= 1.0;
    }
}

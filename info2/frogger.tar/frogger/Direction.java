// Direction in 2D space
public enum Direction {
    UP, DOWN, LEFT, RIGHT
}

// Tests
public class Tests extends de.tuebingen.informatik.Test {
    @org.junit.Test
    public void test()
    {
        new Go();
    }
}
